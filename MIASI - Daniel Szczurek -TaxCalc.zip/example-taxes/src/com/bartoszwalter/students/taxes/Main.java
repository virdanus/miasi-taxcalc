// MIASI - Daniel Szczurek - 96887


package com.bartoszwalter.students.taxes;

public class Main {

	public static void main(String[] args) {
		
		System.out.println("MIASI - Daniel Szczurek - 96887");
		
		System.out.println("Umowa o prac�:");
		UmowaOPrace uop = new UmowaOPrace();		
		MapaPodatkow mp1 = uop.oblicz(2000);		
		SummaryReport sr1 = new SummaryReport();		
		mp1.accept(sr1);
		
		System.out.println("Umowa zlecenie:");
		UmowaZlecenie uz = new UmowaZlecenie();
		MapaPodatkow mp2 = uz.oblicz(2000);
		SummaryReport sr2 = new SummaryReport();
		mp2.accept(sr2);
		
	}

}
