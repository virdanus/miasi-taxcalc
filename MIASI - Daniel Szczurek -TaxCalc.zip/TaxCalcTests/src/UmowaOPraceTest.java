import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import com.bartoszwalter.students.taxes.*;


public class UmowaOPraceTest {
	
	MapaPodatkow mp;

	@Before
    public void Before() 
	{
		UmowaOPrace uop = new UmowaOPrace();		
		mp = uop.oblicz(2000);	   	
    }
	
	@Test
	public void WynagrodzenieBruttoWynosi_2000()
	{	
		assertEquals("Amount was not 2000.00",2000.00,mp.getWynagrodzenieBrutto(),0.01);
	}
	
	@Test
	public void SkladkaNaUbezpieczenieEmerytalneWynosi_195_20()
	{	
		assertEquals("Amount was not 195.20",195.20,mp.getSkladkaNaUbezpieczenieEmerytalne(),0.01);
	}
	
	@Test
	public void SkladkaNaUbezpieczenieRentoweWynosi_30_00()
	{	
		assertEquals("Amount was not 30.00",30.00,mp.getSkladkaNaUbezpieczenieRentowe(),0.01);
	}
	
	@Test
	public void SkladkaNaUbezpieczenieChoroboweWynosi_49_00()
	{	
		assertEquals("Amount was not 49.00",49.00,mp.getSkladkaNaUbezpieczenieChorobowe(),0.01);
	}
	
	@Test
	public void SkladkaNaUbezpieczenieSpoleczneWynosi_274_20()
	{	
		assertEquals("Amount was not 274.20",274.20,mp.getSkladkaNaUbezpieczenieSpoleczne(),0.01);
	}
	
	@Test
	public void PrzychodWynosi_1725_80()
	{	
		assertEquals("Amount was not 1725.80",1725.80,mp.getPrzychod(),0.01);
	}
	
	@Test
	public void KosztyUzyskaniaPrzychoduWynosza_111_25()
	{	
		assertEquals("Amount was not 111.25",111.25,mp.getKosztyUzyskaniaPrzychodu(),0.01);
	}
	
	@Test
	public void DochodWynosi_1614_55()
	{	
		assertEquals("Amount was not 1614.55",1614.55,mp.getDochod(),0.01);
	}
	
	@Test
	public void DochodPoZaokragleniuWynosi_1615()
	{	
		assertEquals("Amount was not 1615.00",1615.00,mp.getDochodZaokraglony(),0.00);
	}
	
	@Test
	public void ZaliczkaNaPodatekWynosi_290_70()
	{	
		assertEquals("Amount was not 290.70",290.70,mp.getZaliczkaNaPodatek(),0.01);
	}
	
	@Test
	public void SkladkaNaUbezpieczenieZdrowotneWynosi_133_75()
	{	
		assertEquals("Amount was not 133.75",133.75,mp.getSkladkaNaUbezpieczenieZdrowotne(),0.01);
	}
	
	@Test
	public void ZaliczkaNaPodatekDochodowyWynosi_110_62()
	{	
		assertEquals("Amount was not 110.62",110.62,mp.getZaliczkaNaPodatekDochodowy(),0.01);
	}
	
	@Test
	public void ZaliczkaNaPodatekDochodowyZaokraglonaWynosi_111_00()
	{	
		assertEquals("Amount was not 111.00",111.00,mp.getZaliczkaNaPodatekDochodowyZaokr�glona(),0.00);
	}
	
	@Test
	public void SkladkiNaUbezpieczenieZdrowotnePobraneWynosza_155_32()
	{	
		assertEquals("Amount was not 155.32",155.32,mp.getSkladkaNaUbezpieczenieZdrowotnePobrana(),0.01);
	}
	
	@Test
	public void WynagrodzenieNettoGdyWynagrodzenieNettoWynosi2000()
	{	
		assertEquals("Amount was not 1459.48",1459.48,mp.getWynagrodzenieNetto(),0.01);
	}

}
