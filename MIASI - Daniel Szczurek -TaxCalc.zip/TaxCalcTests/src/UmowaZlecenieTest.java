import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import com.bartoszwalter.students.taxes.*;

public class UmowaZlecenieTest {

	MapaPodatkow mp;

	@Before
    public void Before() 
	{
		UmowaZlecenie uz = new UmowaZlecenie();		
		mp = uz.oblicz(2000);	   	
    }
	
	@Test
	public void WynagrodzenieBruttoWynosi_2000()
	{	
		assertEquals("Amount was not 2000.00",2000.00,mp.getWynagrodzenieBrutto(),0.01);
	}
	
	@Test
	public void SkladkaNaUbezpieczenieEmerytalneWynosi_195_20()
	{	
		assertEquals("Amount was not 195.20",195.20,mp.getSkladkaNaUbezpieczenieEmerytalne(),0.01);
	}
	
	@Test
	public void SkladkaNaUbezpieczenieRentoweWynosi_30_00()
	{	
		assertEquals("Amount was not 30.00",30.00,mp.getSkladkaNaUbezpieczenieRentowe(),0.01);
	}
	
	@Test
	public void SkladkaNaUbezpieczenieChoroboweWynosi_49_00()
	{	
		assertEquals("Amount was not 49.00",49.00,mp.getSkladkaNaUbezpieczenieChorobowe(),0.01);
	}
	
	@Test
	public void SkladkaNaUbezpieczenieSpoleczneWynosi_274_20()
	{	
		assertEquals("Amount was not 274.20",274.20,mp.getSkladkaNaUbezpieczenieSpoleczne(),0.01);
	}
	
	@Test
	public void PrzychodWynosi_1725_80()
	{	
		assertEquals("Amount was not 1725.80",1725.80,mp.getPrzychod(),0.01);
	}
	
	@Test
	public void KosztyUzyskaniaPrzychoduWynosza_345_16()
	{	
		assertEquals("Amount was not 345.16",345.16,mp.getKosztyUzyskaniaPrzychodu(),0.01);
	}
	
	@Test
	public void DochodWynosi_1380_64()
	{	
		assertEquals("Amount was not 1380.64",1380.64,mp.getDochod(),0.01);
	}
	
	@Test
	public void DochodPoZaokragleniuWynosi_1381()
	{	
		assertEquals("Amount was not 1381.00",1381.00,mp.getDochodZaokraglony(),0.00);
	}
	
	@Test
	public void ZaliczkaNaPodatekWynosi_248_58()
	{	
		assertEquals("Amount was not 248.58",248.58,mp.getZaliczkaNaPodatek(),0.01);
	}
	
	@Test
	public void SkladkaNaUbezpieczenieZdrowotneWynosi_133_75()
	{	
		assertEquals("Amount was not 133.75",133.75,mp.getSkladkaNaUbezpieczenieZdrowotne(),0.01);
	}
	
	@Test
	public void ZaliczkaNaPodatekDochodowyWynosi_114_83()
	{	
		assertEquals("Amount was not 114.83",114.83,mp.getZaliczkaNaPodatekDochodowy(),0.01);
	}
	
	@Test
	public void ZaliczkaNaPodatekDochodowyZaokraglonaWynosi_115_00()
	{	
		assertEquals("Amount was not 115.00",115.00,mp.getZaliczkaNaPodatekDochodowyZaokr�glona(),0.00);
	}
	
	@Test
	public void SkladkiNaUbezpieczenieZdrowotnePobraneWynosza_155_32()
	{	
		assertEquals("Amount was not 155.32",155.32,mp.getSkladkaNaUbezpieczenieZdrowotnePobrana(),0.01);
	}
	
	@Test
	public void WynagrodzenieNettoGdyWynagrodzenieNettoWynosi_1455_48()
	{	
		assertEquals("Amount was not 1455.48",1455.48,mp.getWynagrodzenieNetto(),0.01);
	}

}
