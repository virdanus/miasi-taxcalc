package com.bartoszwalter.students.taxes;

public class UmowaOPrace extends Umowa 
{
	public UmowaOPrace() 
	{
		super();
		setTaxType(new PodatkiPrzyUmowieOPrace());
	}
}
