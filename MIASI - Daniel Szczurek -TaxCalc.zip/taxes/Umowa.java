package com.bartoszwalter.students.taxes;

public abstract class Umowa {

	  private Opodatkowanie podatek;
	  
	  public Umowa() 
	  {
	  }
	 
	  public void setTaxType (Opodatkowanie podatek) 
	  {
	    this.podatek= podatek;
	  }
	  
	 
	  public Opodatkowanie getTaxType() {
		return podatek;
	  }

	public MapaPodatkow oblicz(double podstawaOpodatkowania) 
	  {		 
		MapaPodatkow mp =  podatek.oblicz(podstawaOpodatkowania);		
	    return mp;  
	  }	
	  
}
