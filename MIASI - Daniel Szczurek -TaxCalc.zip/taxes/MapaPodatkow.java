package com.bartoszwalter.students.taxes;

public class MapaPodatkow 
{
	private double kosztyUzyskaniaPrzychodu; 
	private double stopaKosztowUzyskaniaPrzychodu;
	private double stopaPodatku;
	private double stopaSkladkNaUbezpieczenieEmerytalne;
	private double stopaSkladkiNaUbezpieczenieRentowe;
	private double stopaSkladkiNaUbezpieczenieChorobowe;
	private double stopaSkladkiNaUbezpieczenieZdrowotne;
	private double stopaSkladkiNaUbezpieczenieZdrowotnePobrane;	
	private double skladkaNaUbezpieczenieEmerytalne;
	private double skladkaNaUbezpieczenieRentowe;
	private double skladkaNaUbezpieczenieChorobowe;
	private double skladkaNaUbezpieczenieZdrowotne;
	private double skladkaNaUbezpieczenieZdrowotnePobrana;
	private double skladkaNaUbezpieczenieSpoleczne;	
	private double przychod;
	private double dochod;
	private double dochodZaokraglony;	
	private double zaliczkaNaPodatek;
	private double zaliczkaNaPodatekDochodowy;
	private double zaliczkaNaPodatekDochodowyZaokr�glona;
	private double kwotaWolnaOdPodatku;	
	private double wynagrodzenieNetto;
	private double wynagrodzenieBrutto;
	
	public double getStopaKosztowUzyskaniaPrzychodu() {
		return stopaKosztowUzyskaniaPrzychodu;
	}
	public void setStopaKosztowUzyskaniaPrzychodu(double stopaKosztowUzyskaniaPrzychodu) {
		this.stopaKosztowUzyskaniaPrzychodu = stopaKosztowUzyskaniaPrzychodu;
	}
	public double getSkladkaNaUbezpieczenieZdrowotnePobrana() {
		return skladkaNaUbezpieczenieZdrowotnePobrana;
	}
	public void setSkladkaNaUbezpieczenieZdrowotnePobrane(double skladkaNaUbezpieczenieZdrowotnePobrana) {
		this.skladkaNaUbezpieczenieZdrowotnePobrana = skladkaNaUbezpieczenieZdrowotnePobrana;
	}
	public double getStopaSkladkiNaUbezpieczenieZdrowotnePobrane() {
		return stopaSkladkiNaUbezpieczenieZdrowotnePobrane;
	}
	public void setStopaSkladkiNaUbezpieczenieZdrowotnePobrane(double stopaSkladkiNaUbezpieczenieZdrowotnePobrane) {
		this.stopaSkladkiNaUbezpieczenieZdrowotnePobrane = stopaSkladkiNaUbezpieczenieZdrowotnePobrane;
	}
	public double getZaliczkaNaPodatekDochodowyZaokr�glona() {
		return zaliczkaNaPodatekDochodowyZaokr�glona;
	}
	public void setZaliczkaNaPodatekDochodowyZaokr�glona(double zaliczkaNaPodatekDochodowyZaokr�glona) {
		this.zaliczkaNaPodatekDochodowyZaokr�glona = zaliczkaNaPodatekDochodowyZaokr�glona;
	}
	public double getZaliczkaNaPodatek() {
		return zaliczkaNaPodatek;
	}
	public void setZaliczkaNaPodatek(double zaliczkaNaPodatek) {
		this.zaliczkaNaPodatek = zaliczkaNaPodatek;
	}
	public double getStopaSkladkiNaUbezpieczenieZdrowotne() {
		return stopaSkladkiNaUbezpieczenieZdrowotne;
	}
	public void setStopaSkladkiNaUbezpieczenieZdrowotne(double stopaSkladkiNaUbezpieczenieZdrowotne) {
		this.stopaSkladkiNaUbezpieczenieZdrowotne = stopaSkladkiNaUbezpieczenieZdrowotne;
	}
	public double getSkladkaNaUbezpieczenieSpoleczne() {
		return skladkaNaUbezpieczenieSpoleczne;
	}
	public void setSkladkaNaUbezpieczenieSpoleczne(double skladkaNaUbezpieczenieSpoleczne) {
		this.skladkaNaUbezpieczenieSpoleczne = skladkaNaUbezpieczenieSpoleczne;
	}
	public double getStopaPodatku() {
		return stopaPodatku;
	}
	public void setStopaPodatku(double stopaPodatku) {
		this.stopaPodatku = stopaPodatku;
	}
	public double getPrzychod() {
		return przychod;
	}
	public void setPrzychod(double przychod) {
		this.przychod = przychod;
	}
	public double getDochod() {
		return dochod;
	}
	public void setDochod(double dochod) {
		this.dochod = dochod;
	}
	public double getDochodZaokraglony() {
		return dochodZaokraglony;
	}
	public void setDochodZaokraglony(double dochodZaokraglony) {
		this.dochodZaokraglony = dochodZaokraglony;
	}
	public double getWynagrodzenieBrutto() {
		return wynagrodzenieBrutto;
	}
	public void setWynagrodzenieBrutto(double wynagrodzenieBrutto) {
		this.wynagrodzenieBrutto = wynagrodzenieBrutto;
	}
	public double getKosztyUzyskaniaPrzychodu() {
		return kosztyUzyskaniaPrzychodu;
	}
	public void setKosztyUzyskaniaPrzychodu(double kosztyUzyskaniaPrzychodu) {
		this.kosztyUzyskaniaPrzychodu = kosztyUzyskaniaPrzychodu;
	}	
	public double getStopaSkladkNaUbezpieczenieEmerytalne() {
		return stopaSkladkNaUbezpieczenieEmerytalne;
	}
	public void setStopaSkladkNaUbezpieczenieEmerytalne(double stopaSkladkNaUbezpieczenieEmerytalne) {
		this.stopaSkladkNaUbezpieczenieEmerytalne = stopaSkladkNaUbezpieczenieEmerytalne;
	}
	public double getStopaSkladkiNaUbezpieczenieRentowe() {
		return stopaSkladkiNaUbezpieczenieRentowe;
	}
	public void setStopaSkladkiNaUbezpieczenieRentowe(double stopaSkladkiNaUbezpieczenieRentowe) {
		this.stopaSkladkiNaUbezpieczenieRentowe = stopaSkladkiNaUbezpieczenieRentowe;
	}
	public double getStopaSkladkiNaUbezpieczenieChorobowe() {
		return stopaSkladkiNaUbezpieczenieChorobowe;
	}
	public void setStopaSkladkiNaUbezpieczenieChorobowe(double stopaSkladkiNaUbezpieczenieChorobowe) {
		this.stopaSkladkiNaUbezpieczenieChorobowe = stopaSkladkiNaUbezpieczenieChorobowe;
	}
	public double getSkladkaNaUbezpieczenieEmerytalne() {
		return skladkaNaUbezpieczenieEmerytalne;
	}
	public void setSkladkaNaUbezpieczenieEmerytalne(double skladkaNaUbezpieczenieEmerytalne) {
		this.skladkaNaUbezpieczenieEmerytalne = skladkaNaUbezpieczenieEmerytalne;
	}
	public double getSkladkaNaUbezpieczenieRentowe() {
		return skladkaNaUbezpieczenieRentowe;
	}
	public void setSkladkaNaUbezpieczenieRentowe(double skladkaNaUbezpieczenieRentowe) {
		this.skladkaNaUbezpieczenieRentowe = skladkaNaUbezpieczenieRentowe;
	}
	public double getSkladkaNaUbezpieczenieChorobowe() {
		return skladkaNaUbezpieczenieChorobowe;
	}
	public void setSkladkaNaUbezpieczenieChorobowe(double skladkaNaUbezpieczenieChorobowe) {
		this.skladkaNaUbezpieczenieChorobowe = skladkaNaUbezpieczenieChorobowe;
	}
	public double getSkladkaNaUbezpieczenieZdrowotne() {
		return skladkaNaUbezpieczenieZdrowotne;
	}
	public void setSkladkaNaUbezpieczenieZdrowotne(double skladkaNaUbezpieczenieZdrowotne) {
		this.skladkaNaUbezpieczenieZdrowotne = skladkaNaUbezpieczenieZdrowotne;
	}
	public double getZaliczkaNaPodatekDochodowy() {
		return zaliczkaNaPodatekDochodowy;
	}
	public void setZaliczkaNaPodatekDochodowy(double zaliczkaNaPodatekDochodowy) {
		this.zaliczkaNaPodatekDochodowy = zaliczkaNaPodatekDochodowy;
	}
	public double getKwotaWolnaOdPodatku() {
		return kwotaWolnaOdPodatku;
	}
	public void setKwotaWolnaOdPodatku(double kwotaWolnaOdPodatku) {
		this.kwotaWolnaOdPodatku = kwotaWolnaOdPodatku;
	}
	public double getWynagrodzenieNetto() {
		return wynagrodzenieNetto;
	}
	public void setWynagrodzenieNetto(double wynagrodzenieNetto) {
		this.wynagrodzenieNetto = wynagrodzenieNetto;
	}	
	
    public void accept (Report r)
    {   	  
  	  r.visit(this);
    }
}
