package com.bartoszwalter.students.taxes;

public class PodatkiPrzyUmowieOPrace implements Opodatkowanie {
	
	MapaPodatkow mp;
	
	public PodatkiPrzyUmowieOPrace() 
	{
		super();
		mp = new MapaPodatkow();		
		mp.setStopaPodatku(0.18);
		mp.setStopaSkladkNaUbezpieczenieEmerytalne(0.0976);
		mp.setStopaSkladkiNaUbezpieczenieRentowe(0.015);
		mp.setStopaSkladkiNaUbezpieczenieChorobowe(0.0245);
        mp.setStopaSkladkiNaUbezpieczenieZdrowotne(0.0775);
        mp.setStopaSkladkiNaUbezpieczenieZdrowotnePobrane(0.09);
		mp.setKosztyUzyskaniaPrzychodu(111.25);
		mp.setKwotaWolnaOdPodatku(46.33);
	}

	@Override
	public MapaPodatkow oblicz(double podstawaOpodatkowania) {
		
		//System.out.println("Podatki przy umowie o prace:");
		
		mp.setWynagrodzenieBrutto(podstawaOpodatkowania);		
		
		mp.setSkladkaNaUbezpieczenieEmerytalne(mp.getWynagrodzenieBrutto() * mp.getStopaSkladkNaUbezpieczenieEmerytalne());
		mp.setSkladkaNaUbezpieczenieRentowe(mp.getWynagrodzenieBrutto() * mp.getStopaSkladkiNaUbezpieczenieRentowe());
		mp.setSkladkaNaUbezpieczenieChorobowe(mp.getWynagrodzenieBrutto() * mp.getStopaSkladkiNaUbezpieczenieChorobowe());		
		mp.setSkladkaNaUbezpieczenieSpoleczne(mp.getSkladkaNaUbezpieczenieEmerytalne() + mp.getSkladkaNaUbezpieczenieRentowe() + mp.getSkladkaNaUbezpieczenieChorobowe());		
		mp.setPrzychod(mp.getWynagrodzenieBrutto() - mp.getSkladkaNaUbezpieczenieSpoleczne());
		mp.setDochod(mp.getPrzychod() - mp.getKosztyUzyskaniaPrzychodu());
		mp.setDochodZaokraglony(Math.round(mp.getDochod()));		
		mp.setZaliczkaNaPodatek(mp.getDochodZaokraglony() * mp.getStopaPodatku());
		mp.setSkladkaNaUbezpieczenieZdrowotne(mp.getStopaSkladkiNaUbezpieczenieZdrowotne() * mp.getPrzychod());
		mp.setZaliczkaNaPodatekDochodowy(mp.getZaliczkaNaPodatek() - mp.getSkladkaNaUbezpieczenieZdrowotne() - mp.getKwotaWolnaOdPodatku());
		mp.setZaliczkaNaPodatekDochodowyZaokr�glona(Math.round(mp.getZaliczkaNaPodatekDochodowy()));
		mp.setSkladkaNaUbezpieczenieZdrowotnePobrane(mp.getStopaSkladkiNaUbezpieczenieZdrowotnePobrane() * mp.getPrzychod());
		mp.setWynagrodzenieNetto(mp.getPrzychod() - mp.getZaliczkaNaPodatekDochodowyZaokr�glona() - mp.getSkladkaNaUbezpieczenieZdrowotnePobrana());
			
		return mp;
	}
	
}
	
	