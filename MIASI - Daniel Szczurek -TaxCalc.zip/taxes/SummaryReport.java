package com.bartoszwalter.students.taxes;

public class SummaryReport implements Report {

	@Override
	public void visit(MapaPodatkow mp) {
		
		System.out.println("Wynagrodzenie brutto: " + mp.getWynagrodzenieBrutto());
		System.out.println("Sk�adka na ubezpieczenie emerytalne: " + mp.getSkladkaNaUbezpieczenieEmerytalne());
		System.out.println("Sk�adka na ubezpieczenie rentowe: " + mp.getSkladkaNaUbezpieczenieRentowe());
		System.out.println("Sk�adka na ubezpieczenie chorobowe: " + mp.getSkladkaNaUbezpieczenieChorobowe());
		System.out.println("Sk�adka na ubezpieczenie spo�eczne: " + mp.getSkladkaNaUbezpieczenieSpoleczne());
		System.out.println("Przych�d: " + mp.getPrzychod());
		System.out.println("Koszty uzyskania przychodu: " + mp.getKosztyUzyskaniaPrzychodu());
		System.out.println("Doch�d: " + mp.getDochod());
		System.out.println("Zaliczka na podatek: " + mp.getZaliczkaNaPodatek());
		System.out.println("Sk�adka na ubezpieczenie zdrowotne: " + mp.getSkladkaNaUbezpieczenieZdrowotne());
		System.out.println("Zaliczka na podatek dochodowy: " + mp.getZaliczkaNaPodatekDochodowy());
		System.out.println("Sk�adka na ubezpieczenie zdrowotne (pobrane): " + mp.getSkladkaNaUbezpieczenieZdrowotnePobrana());
		System.out.println("Wynagrodzenie netto: " + mp.getWynagrodzenieNetto());
	}
	
}
