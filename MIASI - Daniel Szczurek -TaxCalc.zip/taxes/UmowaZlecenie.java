package com.bartoszwalter.students.taxes;

public class UmowaZlecenie extends Umowa {

	public UmowaZlecenie() 
	{
		super();
		setTaxType(new PodatkiPrzyUmowieZlecenie());
	}

}
