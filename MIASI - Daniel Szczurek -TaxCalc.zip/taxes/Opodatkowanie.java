package com.bartoszwalter.students.taxes;

public interface Opodatkowanie {

	public MapaPodatkow oblicz(double podstawaOpodatkowania);
}
