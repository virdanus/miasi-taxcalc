package com.bartoszwalter.students.taxes;

public interface Report {

	void visit(MapaPodatkow mp);
}
